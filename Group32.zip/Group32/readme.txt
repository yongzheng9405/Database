1. DateChooser.jar and mysql-connector-java-5.1.41-bin.jar needs to be manually imported into library!
2. Group32_Query.txt includes all queries for all the tasks, arranged as their order in source code.
   Please refer to our source code for details of how they function!
3. For user, you can use username as admin, password as admin for test.
   For city scientist, you can use username as sss, password as 150.
   For city official, you can use username as nnn, password as 127.
4. Please use NetBeans IDE to run our source code.
5. If you find the display window's size is not satisfactory to you, 
   feel free to drag and readjust its size.